<p align="center">
    <img src="https://telegra.ph/file/7ff09176639655a9fb919.jpg" width="100%" style="margin-left: auto;margin-right: auto;display: block;">
</p>
<h1 align="center">FangzBOT - MD</h1>
<p align="center">
  <a href="https://github.com/Fangzbotz2007"><img src="http://readme-typing-svg.herokuapp.com?color=FFFFFF&center=true&vCenter=true&multiline=false&lines=Fangz+BOT+Multi+Device;Base+ori+by+BochilGaming;Recode+By+Fangz;Give+star+and+forks+this+Repo+:D;Follow+My+Github" alt="UwU">
</p>

<p align="center">
 <a href="#"><img title="FangzBOT" src="https://img.shields.io/badge/FANGZ BOT-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href=""><img title="Author" src="https://img.shields.io/badge/AUTHOR-FANGZ-blue.svg?style=for-the-badge&logo=github"></a>
</p>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDnetwork/members"><img title="Forks" src="https://img.shields.io/github/forks/Fangzbotz2007/KannaBOT-MD?label=Forks&color=blue&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDlwatchers"><img title="Watchers" src="https://img.shields.io/github/watchers/Fangzbotz2007/KannaBOT-MD?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDstargazers"><img title="Stars" src="https://img.shields.io/github/stars/Fangzbotz2007/KannaBOT-MD?label=Stars&color=yellow&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDgraphs/contributors"><img title="Contributors" src="https://img.shields.io/github/contributors/Fangzbotz2007/KannaBOT-MD?label=Contributors&color=blue&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDissues"><img title="Issues" src="https://img.shields.io/github/issues/Fangzbotz2007/KannaBOT-MD?label=Issues&color=success&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDissues?q=is%3Aissue+is%3Aclosed"><img title="Issues" src="https://img.shields.io/github/issues-closed/Fangzbotz2007/KannaBOT-MD?label=Issues&color=red&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDpulls"><img title="Pull Request" src="https://img.shields.io/github/issues-pr/Fangzbotz2007/KannaBOT-MD?label=PullRequest&color=success&style=flat-square"></a>
<a href="https://github.com/Fangzbotz2007/FangzBOT-MDpulls?q=is%3Apr+is%3Aclosed"><img title="Pull Request" src="https://img.shields.io/github/issues-pr-closed/Fangzbotz2007/KannaBOT-MD?label=PullRequest&color=red&style=flat-square"></a>

---------
## ```Connect With Me 📞``` <img src="https://github.com/siegrin/siegrin/blob/main/Assets/Handshake.gif" height="32px">
  <a href="https://wa.me/6288215689772">
    <img align="left" alt="SIEGRIN | Whastapp" width="26px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Whatsapp.svg" />
  </a> &nbsp;&nbsp;
  <a href="https://tiktok.com/@fangzjb">
    <img align="left" alt="SIEGRIN | Titkok" width="26px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Tiktok.svg" />
  </a> &nbsp;&nbsp;
  <a href="https://instagram.com/fangzganz?igshid=YmMyMTA2M2Y=">
    <img align="left" alt="SIEGRIN | Instagram" width="24px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Instagram.svg" />
  </a> &nbsp;&nbsp;
  <a href="mailto:darmapryanda1@gmail.com">
    <img align="left" alt="SIEGRIN | Gmail" width="26px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Gmail.svg" />
  </a> &nbsp;&nbsp;
---------

## ```Whatsapp``` <a href="https://wa.me/6288215689772"> <img align="left" alt="SIEGRIN | Whastapp" width="26px" src="https://github.com/siegrin/siegrin/blob/main/Assets/Whatsapp.svg" />
[![BOT WHATSAPP](https://img.shields.io/badge/WhatsApp%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/62895394988123) 
[![ONWER](https://img.shields.io/badge/Owner%20BOT-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/6288215689772) 
[![GROUP OFFICIAL](https://img.shields.io/badge/WhatsApp%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/HpxyS6b45SoGIKG7LHddiM) 
---------

#### KELEBIHAN 📍
| Kelebihan | Check |
|--------|--------|
| **Fast Respon** |[✔️](https://github.com/Fangzbotz2007) |
| **No Internet** |[✔️](https://github.com/Fangzbotz2007) |
| **Simple** |[✔️](https://github.com/Fangzbotz2007) |
| **Button template** |[✔️](https://github.com/Fangzbotz2007) |
| **Multi Device** |[✔️](https://github.com/Fangzbotz2007) |
---------
#### FITUR 📍
| Fitur | Check |
|--------|--------|
| **Downloader** |[✔️](https://github.com/Fangzbotz2007) |
| **Internet** |[✔️](https://github.com/Fangzbotz2007) |
| **Game Rpg** |[✔️](https://github.com/Fangzbotz2007) |
| **Nsfw** |[✔️](https://github.com/Fangzbotz2007) |
| **Sticker** |[✔️](https://github.com/Fangzbotz2007) |
| **Game** |[✔️](https://github.com/Fangzbotz2007) |
| **Kerang Ajaib** |[✔️](https://github.com/Fangzbotz2007) |
| **Quotes** |[✔️](https://github.com/Fangzbotz2007) |
| **Anime** |[✔️](https://github.com/Fangzbotz2007) |
| **Premium** |[✔️](https://github.com/Fangzbotz2007) |
| **Tools** |[✔️](https://github.com/Fangzbotz2007) |
| **Exec** |[✔️](https://github.com/Fangzbotz2007) |
| **React** |[✔️](https://github.com/Fangzbotz2007) |
---------

## `SETTING`

- Owner Number [Here](https://github.com/kannachann/kannabot-md/blob/multi-device/config.js#L1)
- Owner Name [Here](https://github.com/kannachann/kannabot-md/blob/multi-device/config.js#L1)
- Bot Name [Here](https://github.com/kannachann/kannabot-md/blob/multi-device/config.js#L1)
---------

## ```Heroku Buildpack```
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/kannachann/KannaBOT-MD)

| BuildPack | LINK |
|--------|--------|
| **FFMPEG** |[here](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest) |
| **IMAGEMAGICK** | [here](https://github.com/DuckyTeam/heroku-buildpack-imagemagick) |

## TERMUX USER
```bash
$ pkg upgrade && pkg update
$ pkg install git -y
$ pkg install nodejs -y
$ pkg install ffmpeg -y
$ pkg install imagemagick -y
$ git clone https://github.com/Fangzbotz2007/FangzBOT-MD
$ cd FangzBOT-MD-master
$ npm i 
```
If error try using yarn instead of npm, see [here](https://github.com/kannachann/KannaBOT-MD#if-npm-install-failed--try--using-yarn-instead-of-npm)
```bash
$ node .
```

#### If npm install failed, try using yarn instead of npm
```bash
$ pkg install yarn -y
$ yarn install
```
---------

## TERMUX WITH UBUNTU

```bash
apt update && apt full-upgrade
apt install wget curl git proot-distro
proot-distro install ubuntu
echo "proot-distro login ubuntu" > $PREFIX/bin/ubuntu
ubuntu
```
---------

[ INSTALLING REQUIRED PACKAGES ]

```bash
ubuntu
apt update && apt full-upgrade
apt install wget curl git ffmpeg imagemagick build-essential libcairo2-dev libpango1.0-dev libjpeg-dev libgif-dev librsvg2-dev dbus-x11 ffmpeg2theora ffmpegfs ffmpegthumbnailer ffmpegthumbnailer-dbg ffmpegthumbs libavcodec-dev libavcodec-extra libavcodec-extra58 libavdevice-dev libavdevice58 libavfilter-dev libavfilter-extra libavfilter-extra7 libavformat-dev libavformat58 libavifile-0.7-bin libavifile-0.7-common libavifile-0.7c2 libavresample-dev libavresample4 libavutil-dev libavutil56 libpostproc-dev libpostproc55 graphicsmagick graphicsmagick-dbg graphicsmagick-imagemagick-compat graphicsmagick-libmagick-dev-compat groff imagemagick-6.q16hdri imagemagick-common libchart-gnuplot-perl libgraphics-magick-perl libgraphicsmagick++-q16-12 libgraphicsmagick++1-dev
```

---------

[ INSTALLING NODEJS & FANGZ BOT-MD]

```bash
ubuntu
curl -fsSL https://deb.nodesource.com/setup_current.x | sudo -E bash -
apt install -y nodejs gcc g++ make
git clone https://github.com/Fangzbotz2007/FangzBOT-MD
cd FangzBOT-MD-master
npm install
npm update
```

---------

## FOR WINDOWS/VPS/RDP USER 💻

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/Fangzbotz2007/FangzBOT-MD
cd FangzBOT-MD-master
npm install
npm update
```

---------

## Run 📛

```bash
node .
```

---------

## ```Arguments node . [--options] [<session name>]```

## `--self`
* Activate self mode (Ignores other)

## `--pconly`
* If that chat not from private bot, bot will ignore

## `--gconly`
* If that chat not from group, bot will ignore

## `--swonly`
* If that chat not from status, bot will ignore

## `--prefix <prefixes>`
* `prefixes` are seperated by each character
Set prefix

## `--server`
* Used for [heroku](https://heroku.com/) or scan through website

## `--restrict`
* Enables restricted plugins (which can lead your number to be **banned** if used too often)
* Group Administration `add, kick`

## `--img`
* Enable image inspector through terminal

## `--autoread`
* If enabled, all incoming messages will be marked as read

## `--nyimak`
* No bot, just print received messages and add users to database

## `--test`
* **Development** Testing Mode

---------

## ```How To Customise Message Display```
```js
// Syntax
conn.sendButton(
      jid, // jid of the user to send the message to
      text, // text to send
      foooter, // footer to send
      buffer, // buffer to send (optional), if you want to send button image, location, etc
      buttons, // buttons to send, example [['text1', 'id1'], ['text2', 'id2']]
      quoted, // quoted message to send (optional)
      options // options to send, example { asLocation: true }
)

// example 
conn.sendButton(m.chat, 'Hello world!', '@BochilGaming', null, [
      ['Hello', 'hello'], ['Bye', 'bye']
])
// example button location
conn.sendButton(m.chat, 'Hello world!', '@BochilGaming', 'https://github.com/BochilGaming', 
      [['Hello', 'hello'], ['Bye', 'bye']], 
      null, { asLocation: true }
)
```
---------

### 📮 S&K
1. Jangan diperjual belikan Script ini
2. Sebelum pakai jangan lupa kasih star
3. Follow Github !
4. Jangan salah gunakan script ini!
5. Jangan lupa Subscribe Youtube
6. Jika ada eror di sc hub Fangz

---------


## ```Thanks to ✨```
* [`Allah SWT`](https://github.com/Fangzbotz2007)
* [`My parents`](https://github.com/Fangzbotz2007)
* [`All Friends`](https://github.com/Fangzbotz2007)
* [`All Contributors`](https://github.com/Fangzbotz2007)
* [`All Creator Bot`](https://github.com/Fangzbotz2007)
* [`Adiwajshing`](https://github.com/adiwajshing/Baileys)
* [`Nurutomo`](https://github.com/nurutomo)
* [`BochilGaming`](https://github.com/bochilgaming)

## ```Recode By 💌```
[![Fangz BOT](https://github.com/Fangzbotz2007.png?size=100)](https://github.com/Fangzbotz2007)

## ```Contributor 📣```
* [`The.Sad.Boy01`](https://github.com/Kangsad01)
* [`AmirulDev20`](https://github.com/amiruldev20)
* [`Rasel Comel`](https://github.com/raselcomel)
* [`Rominaru`](https://github.com/rominaru)
